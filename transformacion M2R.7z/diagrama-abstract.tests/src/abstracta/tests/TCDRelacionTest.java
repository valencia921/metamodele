/**
 */
package abstracta.tests;

import abstracta.TCDRelacion;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>TCD Relacion</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class TCDRelacionTest extends TestCase {

	/**
	 * The fixture for this TCD Relacion test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TCDRelacion fixture = null;

	/**
	 * Constructs a new TCD Relacion test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TCDRelacionTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this TCD Relacion test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(TCDRelacion fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this TCD Relacion test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TCDRelacion getFixture() {
		return fixture;
	}

} //TCDRelacionTest
