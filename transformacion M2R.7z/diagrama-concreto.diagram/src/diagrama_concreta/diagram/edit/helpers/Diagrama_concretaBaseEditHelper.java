/*
 * 
 */
package diagrama_concreta.diagram.edit.helpers;

import org.eclipse.gmf.tooling.runtime.edit.helpers.GeneratedEditHelperBase;

/**
 * @generated
 */
public class Diagrama_concretaBaseEditHelper extends GeneratedEditHelperBase {

}
