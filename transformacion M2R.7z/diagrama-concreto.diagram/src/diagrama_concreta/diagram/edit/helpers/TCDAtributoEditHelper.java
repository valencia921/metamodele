/*
 * 
 */
package diagrama_concreta.diagram.edit.helpers;

/**
 * @generated
 */
public class TCDAtributoEditHelper extends diagrama_concreta.diagram.edit.helpers.Diagrama_concretaBaseEditHelper {
}
