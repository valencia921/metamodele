/*
 * 
 */
package diagrama_concreta.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	* @generated
	*/
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Messages() {
	}

	/**
	* @generated
	*/
	public static String Diagrama_concretaCreationWizardTitle;

	/**
	* @generated
	*/
	public static String Diagrama_concretaCreationWizard_DiagramModelFilePageTitle;

	/**
	* @generated
	*/
	public static String Diagrama_concretaCreationWizard_DiagramModelFilePageDescription;

	/**
	* @generated
	*/
	public static String Diagrama_concretaCreationWizard_DomainModelFilePageTitle;

	/**
	* @generated
	*/
	public static String Diagrama_concretaCreationWizard_DomainModelFilePageDescription;

	/**
	* @generated
	*/
	public static String Diagrama_concretaCreationWizardOpenEditorError;

	/**
	* @generated
	*/
	public static String Diagrama_concretaCreationWizardCreationError;

	/**
	* @generated
	*/
	public static String Diagrama_concretaCreationWizardPageExtensionError;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDocumentProvider_isModifiable;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDocumentProvider_handleElementContentChanged;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDocumentProvider_IncorrectInputError;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDocumentProvider_NoDiagramInResourceError;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDocumentProvider_DiagramLoadingError;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDocumentProvider_UnsynchronizedFileSaveError;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDocumentProvider_SaveDiagramTask;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDocumentProvider_SaveNextResourceTask;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDocumentProvider_SaveAsOperation;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String InitDiagramFile_WizardTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	* @generated
	*/
	public static String Diagrama_concretaNewDiagramFileWizard_CreationPageName;

	/**
	* @generated
	*/
	public static String Diagrama_concretaNewDiagramFileWizard_CreationPageTitle;

	/**
	* @generated
	*/
	public static String Diagrama_concretaNewDiagramFileWizard_CreationPageDescription;

	/**
	* @generated
	*/
	public static String Diagrama_concretaNewDiagramFileWizard_RootSelectionPageName;

	/**
	* @generated
	*/
	public static String Diagrama_concretaNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	* @generated
	*/
	public static String Diagrama_concretaNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	* @generated
	*/
	public static String Diagrama_concretaNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	* @generated
	*/
	public static String Diagrama_concretaNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	* @generated
	*/
	public static String Diagrama_concretaNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	* @generated
	*/
	public static String Diagrama_concretaNewDiagramFileWizard_InitDiagramCommand;

	/**
	* @generated
	*/
	public static String Diagrama_concretaNewDiagramFileWizard_IncorrectRootError;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDiagramEditor_SavingDeletedFile;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDiagramEditor_SaveAsErrorTitle;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDiagramEditor_SaveAsErrorMessage;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDiagramEditor_SaveErrorTitle;

	/**
	* @generated
	*/
	public static String Diagrama_concretaDiagramEditor_SaveErrorMessage;

	/**
	* @generated
	*/
	public static String Diagrama_concretaElementChooserDialog_SelectModelElementTitle;

	/**
	* @generated
	*/
	public static String ModelElementSelectionPageMessage;

	/**
	* @generated
	*/
	public static String ValidateActionMessage;

	/**
	* @generated
	*/
	public static String Objects1Group_title;

	/**
	* @generated
	*/
	public static String Connections2Group_title;

	/**
	* @generated
	*/
	public static String TCDAtributo1CreationTool_title;

	/**
	* @generated
	*/
	public static String TCDAtributo1CreationTool_desc;

	/**
	* @generated
	*/
	public static String TCDClase2CreationTool_title;

	/**
	* @generated
	*/
	public static String TCDClase2CreationTool_desc;

	/**
	* @generated
	*/
	public static String TCDMetodo3CreationTool_title;

	/**
	* @generated
	*/
	public static String TCDMetodo3CreationTool_desc;

	/**
	* @generated
	*/
	public static String TCDPaquete4CreationTool_title;

	/**
	* @generated
	*/
	public static String TCDPaquete4CreationTool_desc;

	/**
	* @generated
	*/
	public static String TCDAgregacion1CreationTool_title;

	/**
	* @generated
	*/
	public static String TCDAgregacion1CreationTool_desc;

	/**
	* @generated
	*/
	public static String TCDAsociacion2CreationTool_title;

	/**
	* @generated
	*/
	public static String TCDAsociacion2CreationTool_desc;

	/**
	* @generated
	*/
	public static String TCDComposicion3CreationTool_title;

	/**
	* @generated
	*/
	public static String TCDComposicion3CreationTool_desc;

	/**
	* @generated
	*/
	public static String TCDDependencia4CreationTool_title;

	/**
	* @generated
	*/
	public static String TCDDependencia4CreationTool_desc;

	/**
	* @generated
	*/
	public static String TCDHerencia5CreationTool_title;

	/**
	* @generated
	*/
	public static String TCDHerencia5CreationTool_desc;

	/**
	* @generated
	*/
	public static String TCDClaseTCDClaseListaAtributosCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String TCDClaseTCDClaseListaMetodosCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CommandName_OpenDiagram;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDDiagramaClases_1000_links;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDClase_2001_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDClase_2001_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDAsociacion_4001_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDAsociacion_4001_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDComposicion_4002_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDComposicion_4002_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDDependencia_4003_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDDependencia_4003_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDHerencia_4004_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDHerencia_4004_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDAgregacion_4005_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TCDAgregacion_4005_source;

	/**
	* @generated
	*/
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	* @generated
	*/
	public static String MessageFormatParser_InvalidInputError;

	/**
	* @generated
	*/
	public static String Diagrama_concretaModelingAssistantProviderTitle;

	/**
	* @generated
	*/
	public static String Diagrama_concretaModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
