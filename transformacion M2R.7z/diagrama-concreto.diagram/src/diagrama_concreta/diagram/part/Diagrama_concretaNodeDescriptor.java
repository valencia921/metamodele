/*
* 
*/
package diagrama_concreta.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class Diagrama_concretaNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	* @generated
	*/
	public Diagrama_concretaNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
