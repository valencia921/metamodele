/*
 * 
 */
package diagrama_concreta.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.ConnectionsPreferencePage;

/**
 * @generated
 */
public class DiagramConnectionsPreferencePage extends ConnectionsPreferencePage {

	/**
	* @generated
	*/
	public DiagramConnectionsPreferencePage() {
		setPreferenceStore(
				diagrama_concreta.diagram.part.Diagrama_concretaDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
