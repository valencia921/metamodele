/*
 * 
 */
package diagrama_concreta.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class Diagrama_concretaIconProvider extends DefaultElementTypeIconProvider implements IIconProvider {

	/**
	* @generated
	*/
	public Diagrama_concretaIconProvider() {
		super(diagrama_concreta.diagram.providers.Diagrama_concretaElementTypes.TYPED_INSTANCE);
	}

}
