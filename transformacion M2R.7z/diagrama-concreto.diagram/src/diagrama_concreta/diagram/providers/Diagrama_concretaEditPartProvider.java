/*
 * 
 */
package diagrama_concreta.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

/**
 * @generated
 */
public class Diagrama_concretaEditPartProvider extends DefaultEditPartProvider {

	/**
	* @generated
	*/
	public Diagrama_concretaEditPartProvider() {
		super(new diagrama_concreta.diagram.edit.parts.Diagrama_concretaEditPartFactory(),
				diagrama_concreta.diagram.part.Diagrama_concretaVisualIDRegistry.TYPED_INSTANCE,
				diagrama_concreta.diagram.edit.parts.TCDDiagramaClasesEditPart.MODEL_ID);
	}

}
