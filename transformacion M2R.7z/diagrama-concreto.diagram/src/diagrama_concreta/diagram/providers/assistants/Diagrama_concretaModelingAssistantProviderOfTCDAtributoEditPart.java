/*
 * 
 */
package diagrama_concreta.diagram.providers.assistants;

/**
 * @generated
 */
public class Diagrama_concretaModelingAssistantProviderOfTCDAtributoEditPart
		extends diagrama_concreta.diagram.providers.Diagrama_concretaModelingAssistantProvider {

}
