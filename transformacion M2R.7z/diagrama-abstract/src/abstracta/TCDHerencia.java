/**
 */
package abstracta;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>TCD Herencia</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see abstracta.AbstractaPackage#getTCDHerencia()
 * @model
 * @generated
 */
public interface TCDHerencia extends TCDRelacion {
} // TCDHerencia
