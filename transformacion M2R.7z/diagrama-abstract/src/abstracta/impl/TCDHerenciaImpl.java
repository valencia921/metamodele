/**
 */
package abstracta.impl;

import abstracta.AbstractaPackage;
import abstracta.TCDHerencia;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>TCD Herencia</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TCDHerenciaImpl extends TCDRelacionImpl implements TCDHerencia {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TCDHerenciaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AbstractaPackage.Literals.TCD_HERENCIA;
	}

} //TCDHerenciaImpl
