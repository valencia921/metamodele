/**
 */
package diagrama_concreta;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>TCD Herencia</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see diagrama_concreta.Diagrama_concretaPackage#getTCDHerencia()
 * @model annotation="gmf.link source='source' target='target' style='solid' width='3' color='4,255,0' source.decoration='closedarrow'"
 * @generated
 */
public interface TCDHerencia extends TCDRelacion {
} // TCDHerencia
