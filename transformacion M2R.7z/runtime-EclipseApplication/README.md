# Diagrama.test
Parte del proyecto de Ing. software dirigida por modelos. Es el test donde se ubican los diagramas que se crean en la ejecución
